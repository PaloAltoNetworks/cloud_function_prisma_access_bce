import google_auth_httplib2
from google.oauth2.service_account import Credentials
from httplib2 import Http
import os
import json
import requests

PA_API_KEY = os.environ.get('PA_API_KEY')
EMAIL = os.environ.get('EMAIL')
TOKEN = os.environ.get('TOKEN')
CRED_JSON = os.environ.get('CRED_JSON')
ACCESS_POLICY_ID = os.environ.get('ACCESS_POLICY_ID')
ACCESS_LEVEL_ID = os.environ.get('ACCESS_LEVEL_ID')


def upload_ip():
    api_end_point = 'https://api.lab.gpcloudservice.com/getPrismaAccessIP/v2'
    body = {"serviceType": "gp_gateway", "addrType": "all", "location": "all"}
    response = requests.post(api_end_point, json=body, headers={'header-api-key': PA_API_KEY}, verify=False)
    results = response.json()['result']
    updateIPs = []
    for result in results:
        updateIPs.extend(result['addresses'])
    print(updateIPs)

    SCOPES = [
        'https://www.googleapis.com/auth/cloud-platform'
    ]

    # Authorized the http request
    json_obj = json.loads(CRED_JSON)
    cred = Credentials.from_service_account_info(json_obj, scopes=SCOPES, subject=EMAIL)
    http = google_auth_httplib2.AuthorizedHttp(cred, http=Http())

    base_url = 'https://accesscontextmanager.googleapis.com/v1beta/accessPolicies/{}/accessLevels/{}?updateMask=basic'.format(ACCESS_POLICY_ID, ACCESS_LEVEL_ID)
    body = {
        "basic": {
            "conditions": [
                {
                    "ipSubnetworks": updateIPs
                }
            ]
        }
    }
    response = http.request(base_url, method='PATCH', body=json.dumps(body))

def hello_world(request):
    request_json = request.get_json()
    if (request.args and request.args.get('token') == TOKEN) or (request_json and request_json.get('token') == TOKEN):
        upload_ip()
        return 'Successful!'
    else:
        return 'Wrong authentication!'
    
